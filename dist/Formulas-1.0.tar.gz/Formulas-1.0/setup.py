from  setuptools import find_packages, setup

setup(
    name="Formulas",  # Cambié "nombre" a "name"
    version="1.0",
    description="Función suma",
    author="Carlos",
    author_email="j@mail.com",
    packages={"Modulos": "Modulos.paquetes"},  # Indica que "Modulos" es el directorio raíz de los paquetes
)  
