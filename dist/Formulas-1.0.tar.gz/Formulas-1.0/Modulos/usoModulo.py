#Estas son las dos maneras de importar un modulo

#import Formulas
#print(Formulas.suma(3,5))
from paquetes.Formulas import *
from paquetes.subPaquete.resta import *
print(suma(3,5))
print(restar(5,5))